public class Main {

    public static void main(String[] args)

    {

        BinaryTree tree = new BinaryTree();
        tree.insertNode(tree.getRoot(), 4);
        tree.insertNode(tree.getRoot(), 3);
        tree.insertNode(tree.getRoot(), 1);
        tree.insertNode(tree.getRoot(), 6);
        tree.insertNode(tree.getRoot(), 5);
        tree.insertNode(tree.getRoot(), 14);
        tree.euler(tree.getRoot(),0);
        tree.settingH();
      //  tree.printE();
      //  tree.printL();
      //  tree.printH();
        int uKey = 5;
        int vKey = 14;
        int lca = tree.findLCA(tree.getH().get(uKey), tree.getH().get(vKey));

        System.out.println("LCA of " + uKey + " and " + vKey+ " is " + lca);

    }
}
